import re

# Sample text
text = "Hello, my email is john@example.com. Please contact me at john.doe@example.com."

# Regular expression pattern to match email addresses
pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'

# Find all email addresses in the text
matches = re.findall(pattern, text)

# Replace email addresses with a placeholder
masked_text = re.sub(pattern, "[EMAIL]", text)

# Print the matches and the masked text
print("Email addresses found:")
print(matches)
print("\nMasked text:")
print(masked_text)