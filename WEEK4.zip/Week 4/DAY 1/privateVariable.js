let _privateVariable = 'Hello, I am a private variable!';

function getPrivateVariable() {
  return _privateVariable;
}

function setPrivateVariable(newValue) {
  _privateVariable = newValue;
}

module.exports = {
  getPrivateVariable,
  setPrivateVariable,
};