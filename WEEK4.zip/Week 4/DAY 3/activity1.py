# time it module will measure excecution in seconds

import timeit

print(timeit.timeit('"_".join(str(n) for n in range(100))',number=1000))