number = 0
while number < 5:
    number += 1
    print(str(number))
    if number == 5:
        break