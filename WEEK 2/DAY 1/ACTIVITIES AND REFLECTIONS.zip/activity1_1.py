for i in range(1, 10, 3):
    for j in range(i, i+3):
        print(j, end=" ")
    print()