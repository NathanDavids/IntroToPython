import math

print(math.sin)
print(math.sin(10))