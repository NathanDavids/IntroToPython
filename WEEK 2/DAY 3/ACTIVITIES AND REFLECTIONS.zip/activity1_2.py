import module1

x = module1.Car["name"]

print(x)