Car = {
    "name": "Mazda", 
    "color": "Yellow"
}
