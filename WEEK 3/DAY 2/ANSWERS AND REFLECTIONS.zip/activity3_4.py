list1 = [5, 20, 15, 20, 25, 50, 20]

# Remove all occurrences of 20 from the list
while 20 in list1:
    list1.remove(20)

print(list1)