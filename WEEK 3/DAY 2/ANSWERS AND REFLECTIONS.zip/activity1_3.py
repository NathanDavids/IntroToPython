x = [1, 2, 3, 4, 5, 6, 7]
pow2 = [x ** 2 for x in x]
print(pow2)