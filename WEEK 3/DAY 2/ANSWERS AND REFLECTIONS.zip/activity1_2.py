list1 = ["M", "na", "i", "Ke"]
list2 = ["y", "me", "s", "lly"]
result = [list1[i] + list2[i] for i in range(len(list1))]
print(result)