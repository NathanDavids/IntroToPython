list1 = [5, 10, 15, 20, 25, 50, 20]

# Find the index of the first occurrence of 20
index = list1.index(20)

# Replace the value with 200 at the found index
list1[index] = 200

print(list1)