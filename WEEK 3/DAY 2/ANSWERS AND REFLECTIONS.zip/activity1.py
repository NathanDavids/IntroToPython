aList = [100, 200, 300, 400, 500]
aList.reverse()
print(aList)